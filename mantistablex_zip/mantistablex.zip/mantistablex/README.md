### MantistableX Addon

`MantisTableX` plugin converts structured data into natural language descriptions. Given an input table with annotations specifying the relationships and significance of its data, the tool generates coherent textual summaries or narratives that convey the table's information in readable and contextually appropriate sentences.
